import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import type {
  AppNotification,
  AppState,
  Friend,
  GameKey,
  Group,
  ID,
  InviteReply,
  Mission,
  MissionMetric,
  Place,
  RunInvite,
  RunSession,
} from '../types'
import { initialState } from '../lib/seed'
import { bump, emptyCounters, rollover } from '../lib/counters'
import { normalizeCode, uid } from '../lib/id'
import { whenLabel } from '../lib/format'
import { pushNotice } from '../lib/notify'
import { blobToDataUrl, squareThumbnail } from '../lib/image'
import { describeAuthError, isCloudConfigured } from '../lib/supabase'
import * as api from '../lib/api'
import { HEARTBEAT_MS } from '../lib/presence'

const STORAGE_PREFIX = 'wanna-run.state.v1'
export const XP_PER_LEVEL = 250

/** แยกที่เก็บข้อมูลในเครื่องตามบัญชี เพื่อไม่ให้ข้อมูลปนกันเมื่อสลับผู้ใช้ */
function storageKey(userId: string | null): string {
  return userId ? `${STORAGE_PREFIX}:${userId}` : STORAGE_PREFIX
}

function load(userId: string | null): AppState {
  const base = withCounters(initialState())
  if (typeof localStorage === 'undefined') return base
  try {
    const raw = localStorage.getItem(storageKey(userId))
    if (!raw) return base
    const parsed = JSON.parse(raw) as AppState
    if (!parsed || parsed.version !== 1) return base
    const rolled = rollover(parsed.counters ?? emptyCounters())
    return {
      ...withCounters(parsed),
      spots: parsed.spots ?? [],
      counters: rolled ?? parsed.counters,
      missions: rolled
        ? parsed.missions.map((m) => ({ ...m, claimed: m.period === 'season' ? m.claimed : false }))
        : parsed.missions,
    }
  } catch {
    return base
  }
}

function withCounters(s: AppState): AppState {
  return { ...s, counters: s.counters ?? emptyCounters() }
}

function save(state: AppState, userId: string | null) {
  try {
    localStorage.setItem(storageKey(userId), JSON.stringify(state))
  } catch {
    /* พื้นที่เก็บข้อมูลเต็มหรือถูกปิดใช้งาน */
  }
}

export function levelOf(xp: number): { level: number; inLevel: number; need: number } {
  const level = Math.floor(xp / XP_PER_LEVEL) + 1
  return { level, inLevel: xp % XP_PER_LEVEL, need: XP_PER_LEVEL }
}

/** เติมความคืบหน้าภารกิจจากตัวนับตามช่วงเวลา */
export function missionsWithProgress(state: AppState): Mission[] {
  return state.missions.map((m) => ({
    ...m,
    progress: Math.min(m.target, state.counters[m.period][m.metric]),
  }))
}

type Actions = {
  completeOnboarding: (name: string, emoji: string, weeklyGoalKm: number, photo?: File) => void
  setAvatar: (file: File) => Promise<void>
  clearAvatar: () => Promise<void>
  updateProfile: (patch: Partial<AppState['profile']>) => Promise<void>
  resetAll: () => void

  addFriendByCode: (code: string) => { ok: boolean; message: string }
  sendFriendRequest: (friendId: ID) => void
  acceptFriend: (friendId: ID) => void
  declineFriend: (friendId: ID) => void
  removeFriend: (friendId: ID) => void

  createGroup: (name: string, emoji: string, description: string, memberIds: ID[]) => Group
  updateGroup: (groupId: ID, patch: Partial<Group>) => void
  deleteGroup: (groupId: ID) => void

  createInvite: (input: {
    title: string
    place: Place
    startAt: number
    targetKm: number
    note: string
    groupId?: ID
    inviteeIds: ID[]
  }) => RunInvite
  replyInvite: (inviteId: ID, reply: InviteReply) => void
  cancelInvite: (inviteId: ID) => void

  saveRun: (run: RunSession) => void
  deleteRun: (runId: ID) => void

  toggleShareLocation: (on: boolean) => void

  /** บันทึกจุดวิ่งประจำ (ตั้งชื่อใหม่ได้) คืน id ของจุดที่บันทึก */
  addSpot: (place: Place, name?: string) => ID
  removeSpot: (spotId: ID) => void

  claimMission: (missionId: ID) => void
  recordGame: (game: GameKey, score: number, coins: number, xp: number) => void
  markSpun: () => void

  addNotification: (n: Omit<AppNotification, 'id' | 'at' | 'read'>, alsoNotify?: boolean) => void
  markAllRead: () => void
  markRead: (id: ID) => void
}

type Ctx = { state: AppState; actions: Actions; cloud: boolean; syncing: boolean }

const StoreContext = createContext<Ctx | null>(null)

/** ข้อความหัวแจ้งเตือนตามคำตอบของเพื่อน */
const REPLY_TITLE: Record<InviteReply, string> = {
  going: 'ตอบรับแล้ว ✅',
  maybe: 'อาจจะไป 🤔',
  declined: 'ไปไม่ได้ ❌',
}

const AVATARS = ['🦊', '🐼', '🐰', '🐧', '🐨', '🐻', '🐥', '🦁', '🦄', '🐯', '🐸', '🐙']

function hash(str: string): number {
  let h = 0
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0
  return h
}

export function StoreProvider({
  children,
  userId = null,
}: {
  children: ReactNode
  userId?: string | null
}) {
  const cloud = isCloudConfigured && !!userId
  const [state, setState] = useState<AppState>(() => load(userId))
  const [syncing, setSyncing] = useState(cloud)
  const stateRef = useRef(state)
  stateRef.current = state
  const cloudRef = useRef(cloud)
  cloudRef.current = cloud
  // อัปประวัติเก่าในเครื่องขึ้นคลาวด์ครั้งเดียวต่อการล็อกอิน
  const migratedRef = useRef(false)
  // รับความคืบหน้าจากเซิร์ฟเวอร์แค่ครั้งแรก หลังจากนั้นในเครื่องเป็นตัวตั้ง
  const progressLoadedRef = useRef(false)
  // เทียบคำชวนรอบก่อนเพื่อหาว่ามีอะไรใหม่ — ข้ามรอบแรกกันแจ้งเตือนย้อนหลังทั้งกอง
  const invitesSeenRef = useRef(false)

  useEffect(() => {
    save(state, userId)
  }, [state, userId])

  const patch = useCallback((fn: (s: AppState) => AppState) => setState(fn), [])

  const addNotification = useCallback<Actions['addNotification']>(
    (n, alsoNotify = true) => {
      patch((s) => ({
        ...s,
        notifications: [{ ...n, id: uid('nt_'), at: Date.now(), read: false }, ...s.notifications].slice(0, 60),
      }))
      if (alsoNotify) pushNotice(n.title, n.body)
    },
    [patch],
  )

  /** หาว่าคำชวนรอบนี้ต่างจากรอบก่อนตรงไหน แล้วแจ้งเตือนเฉพาะสิ่งที่เพิ่งเกิด */
  const notifyInviteChanges = useCallback(
    (before: RunInvite[], next: RunInvite[]) => {
      const nameOf = (id: ID) => stateRef.current.friends.find((f) => f.id === id)?.name ?? 'เพื่อน'
      const me = stateRef.current.profile.id

      for (const invite of next) {
        const old = before.find((i) => i.id === invite.id)

        // มีคนชวนเราไปวิ่ง (คำชวนใหม่ที่เราไม่ได้เป็นเจ้าภาพ)
        if (!old && !invite.hostIsMe && invite.status === 'open') {
          addNotification({
            kind: 'invite',
            title: `${invite.hostId ? nameOf(invite.hostId) : 'เพื่อน'} ชวนคุณไปวิ่ง 📣`,
            body: `${invite.title} · ${invite.place.name} · ${whenLabel(invite.startAt)}`,
            goto: 'invites',
          })
          continue
        }

        // เพื่อนตอบคำชวนที่เราเป็นเจ้าภาพ
        if (!invite.hostIsMe) continue
        for (const [memberId, reply] of Object.entries(invite.replies)) {
          if (memberId === me) continue
          if (old?.replies[memberId] === reply) continue
          addNotification({
            kind: 'invite',
            title: `${nameOf(memberId)} ${REPLY_TITLE[reply]}`,
            body: `${invite.title} · ${invite.place.name} · ${whenLabel(invite.startAt)}`,
            goto: 'invites',
          })
        }
      }
    },
    [addNotification],
  )

  /** ดึงข้อมูลฝั่งเซิร์ฟเวอร์มาทับส่วนที่เป็นข้อมูลร่วม (โปรไฟล์ เพื่อน กลุ่ม นัดวิ่ง) */
  const refresh = useCallback(async () => {
    if (!cloudRef.current) return
    const local = stateRef.current.profile
    // ใช้ allSettled เพื่อให้ส่วนที่ดึงสำเร็จยังแสดงได้ แม้บางส่วนจะพลาด
    const [profileR, friendsR, groupsR, invitesR, spotsR, runsR, progressR, scoresR] = await Promise.allSettled([
      api.fetchMyProfile({ level: local.level, xp: local.xp, coins: local.coins }),
      api.fetchFriends(),
      api.fetchGroups(),
      api.fetchInvites(),
      api.fetchSpots(),
      api.fetchRuns(),
      api.fetchProgress(),
      api.fetchGameScores(),
    ])

    for (const [what, result] of [
      ['โปรไฟล์', profileR],
      ['เพื่อน', friendsR],
      ['กลุ่ม', groupsR],
      ['นัดวิ่ง', invitesR],
      ['จุดวิ่งประจำ', spotsR],
      ['ประวัติการวิ่ง', runsR],
      ['ความคืบหน้า', progressR],
      ['คะแนนเกม', scoresR],
    ] as const) {
      if (result.status === 'rejected') console.error(`ดึงข้อมูล${what}ไม่สำเร็จ`, result.reason)
    }

    // เพื่อนตอบคำชวน หรือมีคนชวนเราไปวิ่ง — เทียบกับรอบก่อนแล้วแจ้งเตือน
    // (realtime ส่งสัญญาณมาแล้วเรียก refresh อยู่แล้ว ตรงนี้แค่หาว่าอะไรเปลี่ยน)
    if (invitesR.status === 'fulfilled') {
      const before = stateRef.current.invites
      if (invitesSeenRef.current) notifyInviteChanges(before, invitesR.value)
      invitesSeenRef.current = true
    }

    // ประวัติที่เคยเก็บไว้ในเครื่องก่อนมีตารางบนคลาวด์ ให้อัปขึ้นครั้งแรกที่ซิงก์สำเร็จ
    let serverRuns = runsR.status === 'fulfilled' ? runsR.value : null
    if (serverRuns && !migratedRef.current) {
      migratedRef.current = true
      const known = new Set(serverRuns.map((r) => r.startedAt))
      const onlyLocal = stateRef.current.runs.filter((r) => !known.has(r.startedAt))
      if (onlyLocal.length > 0) {
        try {
          const uploaded = await api.uploadLocalRuns(onlyLocal)
          serverRuns = [...uploaded, ...serverRuns].sort((a, b) => b.startedAt - a.startedAt)
          pushNotice('ย้ายประวัติขึ้นคลาวด์แล้ว', `${uploaded.length} กิจกรรมที่เคยอยู่ในเครื่องนี้`)
        } catch (err) {
          console.error('อัปประวัติเก่าไม่สำเร็จ', err)
        }
      }
    }

    setState((s) => {
      // ความคืบหน้าเอาค่าจากเซิร์ฟเวอร์เฉพาะครั้งแรก หลังจากนั้นในเครื่องเป็นตัวตั้ง
      // แล้วค่อยส่งขึ้นไปทับ (ไม่งั้นสแนปช็อตเก่าจะย้อน XP ที่เพิ่งได้)
      // ถือว่า "โหลดแล้ว" เมื่อถามเซิร์ฟเวอร์สำเร็จ แม้จะยังไม่มีแถว (ผู้ใช้ใหม่)
      // ไม่งั้นจะติดล็อก: รอค่าจากเซิร์ฟเวอร์ก่อนถึงจะยอมเขียน แต่แถวไม่มีวันถูกสร้าง
      const progress = progressR.status === 'fulfilled' ? progressR.value : null
      const takeProgress = progress && !progressLoadedRef.current
      if (progressR.status === 'fulfilled') progressLoadedRef.current = true
      const scores = scoresR.status === 'fulfilled' ? scoresR.value : null

      const profile = profileR.status === 'fulfilled' && profileR.value ? profileR.value : s.profile
      return {
        ...s,
        onboarded: profileR.status === 'fulfilled' ? !!profileR.value : s.onboarded,
        profile: takeProgress
          ? { ...profile, xp: progress.xp, coins: progress.coins, level: levelOf(progress.xp).level }
          : profile,
        counters: takeProgress ? progress.counters : s.counters,
        missions: takeProgress
          ? s.missions.map((m) => ({ ...m, claimed: progress.claimed.includes(m.id) }))
          : s.missions,
        lastSpinAt: takeProgress ? progress.lastSpinAt : s.lastSpinAt,
        // คะแนนเกมเอาค่าที่สูงกว่าเสมอ กันกรณีเล่นบนอีกเครื่องแล้วยังไม่ได้ซิงก์
        highScores: scores
          ? { ...s.highScores, ...Object.fromEntries(Object.entries(scores).map(([g, v]) => [g, Math.max(v ?? 0, s.highScores[g as GameKey] ?? 0)])) }
          : s.highScores,
        friends: friendsR.status === 'fulfilled' ? friendsR.value : s.friends,
        groups: groupsR.status === 'fulfilled' ? groupsR.value : s.groups,
        invites: invitesR.status === 'fulfilled' ? invitesR.value : s.invites,
        spots: spotsR.status === 'fulfilled' ? spotsR.value : s.spots,
        runs: serverRuns ?? s.runs,
      }
    })
    setSyncing(false)
  }, [notifyInviteChanges])

  // โหลดข้อมูลครั้งแรกและติดตามการเปลี่ยนแปลงแบบสด
  useEffect(() => {
    if (!cloud) {
      setSyncing(false)
      return
    }
    setSyncing(true)
    setState(load(userId))
    void refresh()
    const unsubscribe = api.subscribeToChanges((table, row) => {
      // heartbeat ของเพื่อนมาทุกนาทีต่อคน ถ้าดึงข้อมูลใหม่ทุกครั้งจะเปลืองมาก
      // แค่แปะเวลาที่เห็นล่าสุดลงไปพอ ส่วนของตัวเองไม่ต้องทำอะไร
      if (table === 'profiles' && row) {
        if (row.id === userId) return
        let patched = false
        setState((s) => {
          const friend = s.friends.find((f) => f.id === row.id)
          if (!friend) return s
          const seen = api.heartbeatOnly(row, friend)
          if (seen === null) return s
          patched = true
          if (seen.lastActiveAt === friend.lastActiveAt && seen.online === friend.online) return s
          return { ...s, friends: s.friends.map((f) => (f.id === row.id ? { ...f, ...seen } : f)) }
        })
        if (patched) return
      }
      void refresh()
    })

    // Realtime ผ่าน websocket อาจต่อไม่ได้ (เน็ตองค์กร พร็อกซี มือถือสลับสัญญาณ)
    // จึงถามซ้ำเป็นระยะและตอนกลับมาโฟกัสหน้าจอ เพื่อไม่ให้ข้อมูลค้างเมื่อ websocket หลุด
    const timer = window.setInterval(() => void refresh(), 30_000)
    const onWake = () => {
      if (document.visibilityState === 'visible') void refresh()
    }
    document.addEventListener('visibilitychange', onWake)
    window.addEventListener('focus', onWake)

    // heartbeat บอกเพื่อนว่ายังออนไลน์ ส่งตอนเปิดอยู่ และบอกลา (online=false) ทันทีตอนถูกย่อ/ปิด
    // (เบราว์เซอร์มือถือหยุด JS ของแท็บเบื้องหลัง จึงสัญญาว่าออนไลน์ต่อไม่ได้)
    const beat = (online: boolean, keepalive = false) => api.touchPresence(online, keepalive).catch(() => undefined)
    void beat(true)
    const heart = window.setInterval(() => {
      if (document.visibilityState === 'visible') void beat(true)
    }, HEARTBEAT_MS)
    const onHide = () => {
      if (document.visibilityState === 'hidden') void beat(false, true)
      else void beat(true)
    }
    const onLeave = () => void beat(false, true)
    document.addEventListener('visibilitychange', onHide)
    window.addEventListener('pagehide', onLeave)

    return () => {
      unsubscribe()
      window.clearInterval(timer)
      window.clearInterval(heart)
      document.removeEventListener('visibilitychange', onHide)
      window.removeEventListener('pagehide', onLeave)
      document.removeEventListener('visibilitychange', onWake)
      window.removeEventListener('focus', onWake)
    }
  }, [cloud, userId, refresh])

  // ส่ง XP เหรียญ ตัวนับ และภารกิจที่รับรางวัลแล้วขึ้นคลาวด์
  // หน่วงไว้ 3 วินาทีเพราะค่าพวกนี้เปลี่ยนถี่ (เล่นเกมทีละหลายครั้ง)
  const claimedKey = state.missions.filter((m) => m.claimed).map((m) => m.id).join(',')
  useEffect(() => {
    if (!cloud || !progressLoadedRef.current) return
    const timer = window.setTimeout(() => {
      void api
        .saveProgress({
          xp: state.profile.xp,
          coins: state.profile.coins,
          counters: state.counters,
          claimed: claimedKey ? claimedKey.split(',') : [],
          lastSpinAt: state.lastSpinAt,
        })
        .catch((err: Error) => console.error('เก็บความคืบหน้าไม่สำเร็จ', err))
      // คะแนนสัปดาห์นี้เก็บไว้บนโปรไฟล์ด้วย เพราะเป็นข้อมูลที่เพื่อนต้องเห็นบนกระดาน
      void api
        .updateWeeklyScore(state.counters.weekly.gameScore)
        .catch((err: Error) => console.error('เก็บคะแนนสัปดาห์ไม่สำเร็จ', err))
    }, 3000)
    return () => window.clearTimeout(timer)
  }, [cloud, state.profile.xp, state.profile.coins, state.counters, claimedKey, state.lastSpinAt])

  // ตรวจข้ามวัน/ข้ามสัปดาห์เพื่อรีเซ็ตภารกิจ
  useEffect(() => {
    const timer = setInterval(() => {
      setState((s) => {
        const rolled = rollover(s.counters)
        if (!rolled) return s
        return {
          ...s,
          counters: rolled,
          missions: s.missions.map((m) => (m.period === 'season' ? m : { ...m, claimed: false })),
        }
      })
    }, 60_000)
    return () => clearInterval(timer)
  }, [])

  const actions = useMemo<Actions>(() => {
    const bumpMetric = (s: AppState, metric: MissionMetric, amount: number): AppState => ({
      ...s,
      counters: bump(s.counters, metric, amount),
    })

    /** เรียก API แล้วรีเฟรช พร้อมแจ้งเตือนเมื่อพลาด */
    const remote = (fn: () => Promise<unknown>) => {
      fn()
        .then(() => refresh())
        .catch((err: Error) => {
          console.error(err)
          pushNotice('ซิงก์ไม่สำเร็จ', err.message || 'ลองใหม่อีกครั้ง')
        })
    }

    return {
      completeOnboarding: (name, emoji, weeklyGoalKm, photo) => {
        const clean = name.trim() || 'นักวิ่งนิรนาม'
        if (cloudRef.current) {
          const local = stateRef.current.profile
          remote(async () => {
            const profile = await api.createMyProfile(clean, emoji, weeklyGoalKm, {
              level: local.level,
              xp: local.xp,
              coins: local.coins,
            })
            setState((s) => ({ ...s, onboarded: true, profile }))
            // อัปรูปหลังมีแถวโปรไฟล์แล้วเท่านั้น ไม่งั้นอัปเดตที่อยู่รูปไม่ได้
            if (photo) {
              const url = await api.uploadAvatar(photo)
              setState((s) => ({ ...s, profile: { ...s.profile, avatarUrl: url } }))
            }
          })
          return
        }
        patch((s) => ({
          ...s,
          onboarded: true,
          profile: { ...s.profile, name: clean, emoji, weeklyGoalKm },
        }))
        if (photo) void actionsRef.current.setAvatar(photo)
      },

      setAvatar: async (file) => {
        if (cloudRef.current) {
          const url = await api.uploadAvatar(file)
          patch((s) => ({ ...s, profile: { ...s.profile, avatarUrl: url } }))
          return
        }
        // โหมดในเครื่อง: เก็บรูปย่อเป็น data URL ลง localStorage
        const dataUrl = await blobToDataUrl(await squareThumbnail(file))
        patch((s) => ({ ...s, profile: { ...s.profile, avatarUrl: dataUrl } }))
      },

      clearAvatar: async () => {
        if (cloudRef.current) await api.removeAvatar()
        patch((s) => ({ ...s, profile: { ...s.profile, avatarUrl: undefined } }))
      },

      updateProfile: async (p) => {
        const before = stateRef.current.profile
        patch((s) => ({ ...s, profile: { ...s.profile, ...p } }))
        if (!cloudRef.current) return
        try {
          await api.updateMyProfile(p)
        } catch (err) {
          // เซิร์ฟเวอร์ไม่รับ (เช่น ชื่อซ้ำ) ย้อนเฉพาะฟิลด์ที่เพิ่งแก้กลับเป็นค่าเดิม
          const revert = Object.fromEntries(Object.keys(p).map((k) => [k, before[k as keyof typeof before]]))
          patch((s) => ({ ...s, profile: { ...s.profile, ...revert } }))
          throw new Error(describeAuthError((err as Error).message))
        }
      },

      resetAll: () => {
        try {
          localStorage.removeItem(storageKey(userId))
        } catch {
          /* ไม่มีอะไรให้ลบ */
        }
        setState(withCounters(initialState()))
        if (cloudRef.current) void refresh()
      },

      addFriendByCode: (raw) => {
        const code = normalizeCode(raw)
        if (!/^RUN-[A-Z0-9]{4}$/.test(code)) {
          return { ok: false, message: 'รูปแบบรหัสไม่ถูกต้อง (ตัวอย่าง RUN-7KQ2)' }
        }
        const s = stateRef.current
        if (code === s.profile.code) return { ok: false, message: 'นี่คือรหัสของคุณเอง 😄' }

        if (cloudRef.current) {
          remote(async () => {
            const message = await api.sendFriendRequestByCode(code)
            pushNotice('เพิ่มเพื่อน', message)
          })
          return { ok: true, message: 'กำลังส่งคำขอ...' }
        }

        const existing = s.friends.find((f) => f.code === code)
        if (existing?.status === 'friend') return { ok: false, message: `${existing.name} เป็นเพื่อนคุณอยู่แล้ว` }
        if (existing?.status === 'outgoing') return { ok: false, message: 'ส่งคำขอไปแล้ว รอตอบรับอยู่' }
        if (existing) {
          actionsRef.current.sendFriendRequest(existing.id)
          return { ok: true, message: `ส่งคำขอถึง ${existing.name} แล้ว` }
        }

        // ไม่มีเซิร์ฟเวอร์กลางจึงดึงชื่อจริงของเจ้าของรหัสมาไม่ได้
        // ใช้ตัวรหัสเป็นชื่อไปเลย ดีกว่าตั้งชื่อสุ่มที่ทำให้เข้าใจผิดว่าเป็นคนนั้นจริง ๆ
        const h = hash(code)
        const invented: Friend = {
          id: uid('fr_'),
          name: code,
          emoji: AVATARS[(h >> 3) % AVATARS.length],
          code,
          status: 'outgoing',
          bio: 'เพิ่มด้วยรหัสในโหมดทดลอง — ยังไม่ได้เชื่อมเซิร์ฟเวอร์',
          totalKm: 20 + (h % 400),
          avgPaceSec: 280 + (h % 220),
          home: { lat: 13.7305 + ((h % 100) - 50) / 5000, lng: 100.5418 + ((h % 71) - 35) / 5000 },
          sharingLocation: false,
          lastActiveAt: Date.now(),
          weeklyScore: 0,
        }
        patch((s2) => ({ ...s2, friends: [...s2.friends, invented] }))
        scheduleAccept(invented)
        return { ok: true, message: `ส่งคำขอถึงรหัส ${code} แล้ว` }
      },

      sendFriendRequest: (friendId) => {
        const target = stateRef.current.friends.find((f) => f.id === friendId)
        if (!target) return
        if (cloudRef.current) {
          remote(() => api.sendFriendRequestByCode(target.code))
          return
        }
        patch((s) => ({
          ...s,
          friends: s.friends.map((f) => (f.id === friendId ? { ...f, status: 'outgoing' } : f)),
        }))
        scheduleAccept(target)
      },

      acceptFriend: (friendId) => {
        const f = stateRef.current.friends.find((x) => x.id === friendId)
        if (cloudRef.current) {
          remote(async () => {
            await api.acceptFriendRequest(friendId)
            patch((s) => bumpMetric(s, 'friendAdded', 1))
          })
        } else {
          patch((s) =>
            bumpMetric(
              { ...s, friends: s.friends.map((x) => (x.id === friendId ? { ...x, status: 'friend' } : x)) },
              'friendAdded',
              1,
            ),
          )
        }
        if (f) {
          addNotification({
            kind: 'friend',
            title: 'เป็นเพื่อนกันแล้ว 🎉',
            body: `${f.name} เข้าร่วมก๊วนของคุณ`,
            goto: 'friends',
          })
        }
      },

      declineFriend: (friendId) => {
        if (cloudRef.current) {
          remote(() => api.removeFriendship(friendId))
          return
        }
        patch((s) => ({ ...s, friends: s.friends.filter((f) => f.id !== friendId) }))
      },

      removeFriend: (friendId) => {
        if (cloudRef.current) {
          remote(() => api.removeFriendship(friendId))
          return
        }
        patch((s) => ({
          ...s,
          friends: s.friends.filter((f) => f.id !== friendId),
          groups: s.groups.map((g) => ({ ...g, memberIds: g.memberIds.filter((id) => id !== friendId) })),
        }))
      },

      createGroup: (name, emoji, description, memberIds) => {
        const group: Group = {
          id: uid('gp_'),
          name: name.trim() || 'ก๊วนไม่มีชื่อ',
          emoji,
          description: description.trim(),
          memberIds,
          createdAt: Date.now(),
        }
        patch((s) => bumpMetric(s, 'groupCreated', 1))
        if (cloudRef.current) {
          remote(() => api.createGroupRemote(group.name, emoji, group.description, memberIds))
        } else {
          patch((s) => ({ ...s, groups: [group, ...s.groups] }))
        }
        addNotification({
          kind: 'group',
          title: `สร้างกลุ่ม ${group.name}`,
          body: `สมาชิก ${memberIds.length + 1} คน พร้อมลุย!`,
          goto: 'groups',
        })
        return group
      },

      updateGroup: (groupId, p) => {
        if (cloudRef.current) {
          remote(() => api.updateGroupRemote(groupId, p))
          return
        }
        patch((s) => ({ ...s, groups: s.groups.map((g) => (g.id === groupId ? { ...g, ...p } : g)) }))
      },

      deleteGroup: (groupId) => {
        if (cloudRef.current) {
          remote(() => api.deleteGroupRemote(groupId))
          return
        }
        patch((s) => ({ ...s, groups: s.groups.filter((g) => g.id !== groupId) }))
      },

      createInvite: (input) => {
        const invite: RunInvite = {
          id: uid('iv_'),
          title: input.title.trim() || 'ชวนวิ่ง',
          place: input.place,
          startAt: input.startAt,
          targetKm: input.targetKm,
          note: input.note.trim(),
          groupId: input.groupId,
          inviteeIds: input.inviteeIds,
          replies: {},
          hostIsMe: true,
          myReply: 'going',
          createdAt: Date.now(),
          status: 'open',
        }
        patch((s) => bumpMetric(s, 'inviteSent', 1))
        if (cloudRef.current) {
          remote(() => api.createInviteRemote({ ...input, title: invite.title, note: invite.note }))
        } else {
          patch((s) => ({ ...s, invites: [invite, ...s.invites] }))
          scheduleReplies(invite)
        }
        return invite
      },

      replyInvite: (inviteId, reply) => {
        patch((s) => ({
          ...s,
          invites: s.invites.map((i) => (i.id === inviteId ? { ...i, myReply: reply } : i)),
        }))
        if (cloudRef.current) remote(() => api.replyInviteRemote(inviteId, reply))
      },

      cancelInvite: (inviteId) => {
        if (cloudRef.current) {
          remote(() => api.cancelInviteRemote(inviteId))
          return
        }
        patch((s) => ({
          ...s,
          invites: s.invites.map((i) => (i.id === inviteId ? { ...i, status: 'cancelled' } : i)),
        }))
      },

      saveRun: (run) => {
        patch((s) => {
          let next: AppState = { ...s, runs: [run, ...s.runs] }
          next = bumpMetric(next, 'runCount', 1)
          next = bumpMetric(next, 'distanceKm', run.distanceM / 1000)
          const gainedXp = Math.round((run.distanceM / 1000) * 20) + 15
          next = { ...next, profile: { ...next.profile, xp: next.profile.xp + gainedXp } }

          if (cloudRef.current) {
            const totalKm = next.runs.reduce((sum, r) => sum + r.distanceM, 0) / 1000
            const totalMs = next.runs.reduce((sum, r) => sum + r.movingMs, 0)
            const pace = totalKm > 0 ? Math.round(totalMs / 1000 / totalKm) : null
            void api.updateMyStats(totalKm, pace).catch(console.error)
            void api.saveRunRemote(run).catch((err: Error) => {
              console.error(err)
              pushNotice('เก็บกิจกรรมขึ้นคลาวด์ไม่สำเร็จ', 'ยังอยู่ในเครื่องนี้ เดี๋ยวลองใหม่ตอนเชื่อมต่อได้')
            })
          }
          return next
        })
        addNotification({
          kind: 'run',
          title: 'บันทึกการวิ่งแล้ว 🏁',
          body: `${(run.distanceM / 1000).toFixed(2)} กม. เก็บ XP เพิ่ม!`,
          goto: 'profile',
        })
      },

      deleteRun: (runId) => {
        patch((s) => ({ ...s, runs: s.runs.filter((r) => r.id !== runId) }))
        if (cloudRef.current) void api.deleteRunRemote(runId).catch(console.error)
      },

      toggleShareLocation: (on) => {
        patch((s) => {
          const next = { ...s, profile: { ...s.profile, sharingLocation: on } }
          return on ? bumpMetric(next, 'locationShared', 1) : next
        })
        if (cloudRef.current) {
          void api.updateMyProfile({ sharingLocation: on }).catch(console.error)
          if (!on) void api.clearMyLocation().catch(console.error)
        }
        if (on) {
          addNotification({
            kind: 'location',
            title: 'กำลังแชร์ตำแหน่ง',
            body: 'เพื่อนในก๊วนเห็นตำแหน่งคุณบนแผนที่แล้ว',
            goto: 'map',
          })
        }
      },

      addSpot: (place, name) => {
        const spot: Place = {
          ...place,
          id: cloudRef.current ? api.newId() : uid('sp_'),
          name: (name ?? place.name).trim() || place.name,
          tags: ['จุดประจำ'],
        }
        patch((s) => ({ ...s, spots: [spot, ...s.spots.filter((x) => x.id !== spot.id)] }))
        if (cloudRef.current) remote(() => api.createSpotRemote(spot))
        return spot.id
      },

      removeSpot: (spotId) => {
        patch((s) => ({ ...s, spots: s.spots.filter((x) => x.id !== spotId) }))
        if (cloudRef.current) remote(() => api.deleteSpotRemote(spotId))
      },

      claimMission: (missionId) =>
        patch((s) => {
          const m = s.missions.find((x) => x.id === missionId)
          if (!m || m.claimed) return s
          if (s.counters[m.period][m.metric] < m.target) return s
          return {
            ...s,
            missions: s.missions.map((x) => (x.id === missionId ? { ...x, claimed: true } : x)),
            profile: { ...s.profile, xp: s.profile.xp + m.xp, coins: s.profile.coins + m.coins },
          }
        }),

      recordGame: (game, score, coins, xp) =>
        patch((s) => {
          let next = bumpMetric(s, 'gamePlayed', 1)
          next = bumpMetric(next, 'gameScore', score)
          const best = Math.max(next.highScores[game] ?? 0, score)
          if (cloudRef.current && best > (s.highScores[game] ?? 0)) {
            void api.saveGameScore(game, best).catch(console.error)
          }
          return {
            ...next,
            highScores: { ...next.highScores, [game]: best },
            profile: { ...next.profile, coins: next.profile.coins + coins, xp: next.profile.xp + xp },
          }
        }),

      markSpun: () => patch((s) => ({ ...s, lastSpinAt: Date.now() })),

      addNotification,

      markAllRead: () =>
        patch((s) => ({ ...s, notifications: s.notifications.map((n) => ({ ...n, read: true })) })),

      markRead: (id) =>
        patch((s) => ({
          ...s,
          notifications: s.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
        })),
    }

    /** โหมดในเครื่อง: จำลองว่าอีกฝ่ายกดตอบรับคำขอเป็นเพื่อน */
    function scheduleAccept(friend: Friend) {
      window.setTimeout(() => {
        patch((s) => ({
          ...s,
          friends: s.friends.map((f) =>
            f.id === friend.id && f.status === 'outgoing' ? { ...f, status: 'friend' } : f,
          ),
          counters: bump(s.counters, 'friendAdded', 1),
        }))
        addNotification({
          kind: 'friend',
          title: `${friend.name} ตอบรับคำขอแล้ว`,
          body: 'ชวนไปวิ่งด้วยกันเลย!',
          goto: 'friends',
        })
      }, 3500)
    }

    /** โหมดในเครื่อง: จำลองการตอบรับคำชวนวิ่ง */
    function scheduleReplies(invite: RunInvite) {
      invite.inviteeIds.forEach((friendId, index) => {
        window.setTimeout(
          () => {
            const friend = stateRef.current.friends.find((f) => f.id === friendId)
            if (!friend) return
            const reply: InviteReply = index % 3 === 2 ? 'maybe' : 'going'
            patch((s) => ({
              ...s,
              invites: s.invites.map((i) =>
                i.id === invite.id ? { ...i, replies: { ...i.replies, [friendId]: reply } } : i,
              ),
            }))
            addNotification({
              kind: 'invite',
              title: `${friend.name} ${reply === 'going' ? 'ตอบรับ' : 'อาจจะไป'}`,
              body: `${invite.title} · ${invite.place.name}`,
              goto: 'invites',
            })
          },
          2500 + index * 2600,
        )
      })
    }
  }, [patch, addNotification, refresh, userId])

  const actionsRef = useRef(actions)
  actionsRef.current = actions

  const value = useMemo(() => ({ state, actions, cloud, syncing }), [state, actions, cloud, syncing])
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore(): Ctx {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore ต้องอยู่ภายใน StoreProvider')
  return ctx
}

export function useFriends(status?: Friend['status']): Friend[] {
  const { state } = useStore()
  return useMemo(
    () => (status ? state.friends.filter((f) => f.status === status) : state.friends),
    [state.friends, status],
  )
}
